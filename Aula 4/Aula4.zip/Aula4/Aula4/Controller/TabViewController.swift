//
//  TabViewController.swift
//  Aula3
//
//  Created by Matheus on 2019-02-19.
//  Copyright © 2019 Mocka. All rights reserved.
//

import UIKit

class TabViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.tabBar.barTintColor = .black
    }
}
